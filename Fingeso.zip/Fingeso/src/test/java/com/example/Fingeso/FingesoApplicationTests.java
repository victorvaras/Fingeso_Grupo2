package com.example.Fingeso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FingesoApplicationTests {

	@Test
	void contextLoads() {
	}

}
